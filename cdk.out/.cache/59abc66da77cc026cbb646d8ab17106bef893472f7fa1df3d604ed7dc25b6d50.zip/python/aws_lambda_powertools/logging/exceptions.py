class InvalidLoggerSamplingRateError(Exception):
    pass
