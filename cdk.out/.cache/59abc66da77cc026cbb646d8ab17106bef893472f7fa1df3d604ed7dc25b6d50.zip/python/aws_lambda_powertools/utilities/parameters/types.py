from aws_lambda_powertools.shared.types import Literal

TransformOptions = Literal["json", "binary", "auto", None]
